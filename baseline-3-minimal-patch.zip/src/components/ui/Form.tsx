import React from 'react'

export function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="flex flex-col gap-1 text-sm">
      <span className="text-slate-600">{label}</span>
      {children}
    </label>
  )
}

export function Actions({ children }: { children: React.ReactNode }) {
  return <div className="flex gap-2 mt-4">{children}</div>
}

export function Button({ children, ...rest }: React.ButtonHTMLAttributes<HTMLButtonElement>) {
  return <button {...rest} className={"px-3 py-1.5 rounded-lg border bg-slate-50 hover:bg-slate-100 " + (rest.className ?? "")}>{children}</button>
}
