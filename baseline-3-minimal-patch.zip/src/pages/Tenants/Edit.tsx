import React from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import Card from '@/components/ui/Card'
import { Field, Actions, Button } from '@/components/ui/Form'
import { DataProvider } from '@/data/DataProvider'
import type { Tenant } from '@/domain/types'

const dp = new DataProvider()

export default function TenantEdit() {
  const nav = useNavigate()
  const { id } = useParams()
  const isNew = !id
  const [model, setModel] = React.useState<Tenant | null>(null)
  const [loading, setLoading] = React.useState(true)

  React.useEffect(() => {
    (async () => {
      await dp.init()
      if (id) {
        const t = await dp.getTenantById(id)
        setModel(t || null)
      } else {
        const now = new Date().toISOString()
        setModel({ id: '', fullName: '', status: 'active', createdAt: now, updatedAt: now } as any)
      }
      setLoading(false)
    })()
  }, [id])

  if (loading || !model) return <p className="p-4">טוען…</p>

  const save = async () => {
    if (isNew) {
      const created = await dp.createTenant({ ...(model as any), id: undefined })
      nav(`/tenants/${created.id}`)
    } else {
      await dp.updateTenant(model.id, model)
      nav(`/tenants/${model.id}`)
    }
  }

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-semibold">{isNew ? 'דייר חדש' : 'עריכת דייר'}</h2>
      <Card>
        <div className="grid md:grid-cols-2 gap-3">
          <Field label="שם מלא"><input className="border rounded px-2 py-1" value={model.fullName} onChange={e => setModel({ ...model, fullName: e.target.value })} /></Field>
          <Field label="טלפון"><input className="border rounded px-2 py-1" value={model.phone ?? ''} onChange={e => setModel({ ...model, phone: e.target.value || undefined })} /></Field>
          <Field label="אימייל"><input className="border rounded px-2 py-1" value={model.email ?? ''} onChange={e => setModel({ ...model, email: e.target.value || undefined })} /></Field>
          <Field label="ת.ז./ח.פ"><input className="border rounded px-2 py-1" value={model.idNumber ?? ''} onChange={e => setModel({ ...model, idNumber: e.target.value || undefined })} /></Field>
          <Field label="סטטוס">
            <select className="border rounded px-2 py-1" value={model.status} onChange={e => setModel({ ...model, status: e.target.value as any })}>
              <option value="active">פעיל</option>
              <option value="inactive">לא פעיל</option>
            </select>
          </Field>
        </div>
        <Actions>
          <Button onClick={() => nav(-1)}>ביטול</Button>
          <Button onClick={save}>שמירה</Button>
        </Actions>
      </Card>
    </div>
  )
}
