import React from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import Card from '@/components/ui/Card'
import { Field, Actions, Button } from '@/components/ui/Form'
import { DataProvider } from '@/data/DataProvider'
import type { Property } from '@/domain/types'

const dp = new DataProvider()

export default function PropertyEdit() {
  const nav = useNavigate()
  const { id } = useParams()
  const isNew = !id
  const [model, setModel] = React.useState<Property | null>(null)
  const [loading, setLoading] = React.useState(true)

  React.useEffect(() => {
    (async () => {
      await dp.init()
      if (id) {
        const p = await dp.getPropertyById(id)
        setModel(p || null)
      } else {
        const now = new Date().toISOString()
        setModel({ id: '', name: '', type: 'apartment', status: 'vacant', tenantIds: [], attachmentIds: [], createdAt: now, updatedAt: now })
      }
      setLoading(false)
    })()
  }, [id])

  if (loading || !model) return <p className="p-4">טוען…</p>

  const save = async () => {
    if (isNew) {
      const created = await dp.createProperty({ ...(model as any), id: undefined })
      nav(`/properties/${created.id}`)
    } else {
      await dp.updateProperty(model.id, model)
      nav(`/properties/${model.id}`)
    }
  }

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-semibold">{isNew ? 'נכס חדש' : 'עריכת נכס'}</h2>
      <Card>
        <div className="grid md:grid-cols-2 gap-3">
          <Field label="שם"><input className="border rounded px-2 py-1" value={model.name} onChange={e => setModel({ ...model, name: e.target.value })} /></Field>
          <Field label="סוג">
            <select className="border rounded px-2 py-1" value={model.type} onChange={e => setModel({ ...model, type: e.target.value as any })}>
              <option value="apartment">דירה</option>
              <option value="shop">חנות</option>
              <option value="building">בניין</option>
            </select>
          </Field>
          <Field label="סטטוס">
            <select className="border rounded px-2 py-1" value={model.status} onChange={e => setModel({ ...model, status: e.target.value as any })}>
              <option value="vacant">פנוי</option>
              <option value="occupied">מושכר</option>
              <option value="in_progress">בתהליך</option>
            </select>
          </Field>
          <Field label="כתובת"><input className="border rounded px-2 py-1" value={model.address ?? ''} onChange={e => setModel({ ...model, address: e.target.value || undefined })} /></Field>
          <Field label="שטח (מ״ר)"><input type="number" className="border rounded px-2 py-1" value={model.areaM2 ?? ''} onChange={e => setModel({ ...model, areaM2: e.target.value ? Number(e.target.value) : undefined })} /></Field>
          <Field label="חדרים"><input type="number" className="border rounded px-2 py-1" value={model.rooms ?? ''} onChange={e => setModel({ ...model, rooms: e.target.value ? Number(e.target.value) : undefined })} /></Field>
        </div>
        <Actions>
          <Button onClick={() => nav(-1)}>ביטול</Button>
          <Button onClick={save}>שמירה</Button>
        </Actions>
      </Card>
    </div>
  )
}
