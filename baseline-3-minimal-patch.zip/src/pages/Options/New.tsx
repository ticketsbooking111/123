import React from 'react'
import { useNavigate } from 'react-router-dom'
import Card from '@/components/ui/Card'
import { Field, Actions, Button } from '@/components/ui/Form'
import { DataProvider } from '@/data/DataProvider'

const dp = new DataProvider()

export default function OptionNew() {
  const nav = useNavigate()
  const [model, setModel] = React.useState<any>(() => {
    const qs = new URLSearchParams(location.search)
    return {
      leaseId: qs.get('leaseId') || '',
      startDate: new Date().toISOString().slice(0,10),
      endDate: new Date(Date.now()+1000*60*60*24*365).toISOString().slice(0,10),
      price: 0,
    }
  })

  const save = async () => {
    await dp.addOptionToLease(model.leaseId, {
      startDate: new Date(model.startDate).toISOString(),
      endDate: new Date(model.endDate).toISOString(),
      price: model.price ? Number(model.price) : undefined,
    } as any)
    nav(-1)
  }

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-semibold">אופציה חדשה</h2>
      <Card>
        <div className="grid md:grid-cols-2 gap-3">
          <Field label="Lease ID"><input className="border rounded px-2 py-1" value={model.leaseId} onChange={e => setModel({ ...model, leaseId: e.target.value })} /></Field>
          <Field label="תאריך התחלה"><input type="date" className="border rounded px-2 py-1" value={model.startDate} onChange={e => setModel({ ...model, startDate: e.target.value })} /></Field>
          <Field label="תאריך סיום"><input type="date" className="border rounded px-2 py-1" value={model.endDate} onChange={e => setModel({ ...model, endDate: e.target.value })} /></Field>
          <Field label="מחיר"><input type="number" className="border rounded px-2 py-1" value={model.price} onChange={e => setModel({ ...model, price: Number(e.target.value) })} /></Field>
        </div>
        <Actions>
          <Button onClick={() => nav(-1)}>ביטול</Button>
          <Button onClick={save}>שמירה</Button>
        </Actions>
      </Card>
    </div>
  )
}
