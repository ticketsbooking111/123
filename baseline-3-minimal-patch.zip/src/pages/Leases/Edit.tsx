import React from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import Card from '@/components/ui/Card'
import { Field, Actions, Button } from '@/components/ui/Form'
import { DataProvider } from '@/data/DataProvider'

const dp = new DataProvider()

export default function LeaseEdit() {
  const nav = useNavigate()
  const { id } = useParams()
  const [model, setModel] = React.useState<any>({})
  const [file, setFile] = React.useState<File | null>(null)

  React.useEffect(() => {
    (async () => {
      await dp.init()
      if (id) {
        const l = await dp.getLeaseById(id)
        setModel(l || {})
      } else {
        const qs = new URLSearchParams(location.search)
        setModel({
          tenantId: qs.get('tenantId') || '',
          propertyId: qs.get('propertyId') || '',
          startDate: new Date().toISOString().slice(0,10),
          endDate: new Date(Date.now()+1000*60*60*24*365).toISOString().slice(0,10),
          rentAmount: 0,
          currency: 'ILS',
        })
      }
    })()
  }, [id])

  const save = async () => {
    if (!id) {
      const created = await dp.startLeaseForTenant({
        tenantId: model.tenantId,
        propertyId: model.propertyId,
        startDate: new Date(model.startDate).toISOString(),
        endDate: new Date(model.endDate).toISOString(),
        rentAmount: Number(model.rentAmount),
        currency: model.currency,
      })
      if (file) {
        const fid = await dp.saveFile(file, file.name)
        await dp.updateLease(created.id, { ...created, contractAttachmentId: fid })
      }
      nav(`/tenants/${created.tenantId}`)
    } else {
      let updated = { ...model }
      if (file) {
        const fid = await dp.saveFile(file, file.name)
        updated.contractAttachmentId = fid
      }
      await dp.updateLease(model.id, updated)
      nav(`/tenants/${model.tenantId}`)
    }
  }

  const ready = id || (model.tenantId && model.propertyId)
  if (!ready) return <p className="p-4">טוען… או ספק tenantId & propertyId בכתובת.</p>

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-semibold">{id ? 'עריכת חוזה' : 'חוזה חדש'}</h2>
      <Card>
        <div className="grid md:grid-cols-2 gap-3">
          <Field label="Tenant ID"><input className="border rounded px-2 py-1" value={model.tenantId} onChange={e => setModel({ ...model, tenantId: e.target.value })} /></Field>
          <Field label="Property ID"><input className="border rounded px-2 py-1" value={model.propertyId} onChange={e => setModel({ ...model, propertyId: e.target.value })} /></Field>
          <Field label="תאריך התחלה"><input type="date" className="border rounded px-2 py-1" value={model.startDate?.slice(0,10)} onChange={e => setModel({ ...model, startDate: e.target.value })} /></Field>
          <Field label="תאריך סיום"><input type="date" className="border rounded px-2 py-1" value={model.endDate?.slice(0,10)} onChange={e => setModel({ ...model, endDate: e.target.value })} /></Field>
          <Field label="שכ״ד"><input type="number" className="border rounded px-2 py-1" value={model.rentAmount} onChange={e => setModel({ ...model, rentAmount: Number(e.target.value) })} /></Field>
          <Field label="מטבע">
            <select className="border rounded px-2 py-1" value={model.currency} onChange={e => setModel({ ...model, currency: e.target.value })}>
              <option value="ILS">ILS</option>
              <option value="USD">USD</option>
              <option value="EUR">EUR</option>
            </select>
          </Field>
          <Field label="קובץ חוזה (PDF/תמונה)"><input type="file" onChange={e => setFile(e.target.files?.[0] || null)} /></Field>
        </div>
        <Actions>
          <Button onClick={() => nav(-1)}>ביטול</Button>
          <Button onClick={save}>שמירה</Button>
        </Actions>
      </Card>
    </div>
  )
}
