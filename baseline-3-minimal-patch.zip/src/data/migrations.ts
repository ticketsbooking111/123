// Example migration helpers

export async function migrateToV2(db: any) {
  // Dexie יוצר את הטבלה החדשה (files) אוטומטית לפי הסכמה ב-db.ts
  // כאן נשאיר no-op לצורך עקביות/תיעוד.
  return
}
