import db from './db'
import { nanoid } from 'nanoid'
import { propertySchema, tenantSchema, leaseSchema, optionSchema } from '@/domain/schemas'
import type { Property, Tenant, Lease, Option } from '@/domain/types'

export class DataProvider {
  private _inited = false
  async init() {
    if (this._inited) return
    await db.open()
    this._inited = true
  }

  // Files
  async saveFile(blob: Blob, name: string): Promise<string> {
    await this.init()
    const id = nanoid()
    await (db as any).files.put({ id, name, createdAt: new Date().toISOString(), blob })
    return id
  }
  async getFile(id: string): Promise<Blob | undefined> {
    await this.init()
    const rec = await (db as any).files.get(id)
    return rec?.blob as Blob | undefined
  }
  async removeFile(id: string): Promise<void> {
    await this.init()
    await (db as any).files.delete(id)
  }

  // Properties
  async listProperties(): Promise<Property[]> {
    await this.init()
    return db.table('properties').toArray()
  }
  async getPropertyById(id: string): Promise<Property | undefined> {
    await this.init()
    return db.table('properties').get(id)
  }
  async createProperty(input: Omit<Property, 'id'> & Partial<Pick<Property, 'id'>>): Promise<Property> {
    await this.init()
    const now = new Date().toISOString()
    const entity: Property = { id: input.id || nanoid(), ...input, createdAt: input.createdAt || now, updatedAt: now } as any
    propertySchema.parse(entity)
    await db.table('properties').add(entity)
    return entity
  }
  async updateProperty(id: string, patch: Partial<Property>): Promise<Property> {
    await this.init()
    const current = await this.getPropertyById(id)
    if (!current) throw new Error('Property not found')
    const updated = { ...current, ...patch, id, updatedAt: new Date().toISOString() } as Property
    propertySchema.parse(updated)
    await db.table('properties').put(updated)
    return updated
  }
  async removeProperty(id: string): Promise<void> {
    await this.init()
    // simple guard: prevent delete if tenants or leases linked
    const leases = await db.table('leases').where({ propertyId: id }).count()
    const tenants = await db.table('tenants').where({ propertyId: id }).count()
    if (leases > 0 || tenants > 0) throw new Error('Cannot delete property with linked tenants/leases')
    await db.table('properties').delete(id)
  }

  // Tenants
  async listTenants(): Promise<Tenant[]> {
    await this.init()
    return db.table('tenants').toArray()
  }
  async getTenantById(id: string): Promise<Tenant | undefined> {
    await this.init()
    return db.table('tenants').get(id)
  }
  async createTenant(input: Omit<Tenant, 'id'> & Partial<Pick<Tenant, 'id'>>): Promise<Tenant> {
    await this.init()
    const now = new Date().toISOString()
    const entity: Tenant = { id: input.id || nanoid(), ...input, createdAt: input.createdAt || now, updatedAt: now } as any
    tenantSchema.parse(entity)
    await db.table('tenants').add(entity)
    return entity
  }
  async updateTenant(id: string, patch: Partial<Tenant>): Promise<Tenant> {
    await this.init()
    const current = await this.getTenantById(id)
    if (!current) throw new Error('Tenant not found')
    const updated = { ...current, ...patch, id, updatedAt: new Date().toISOString() } as Tenant
    tenantSchema.parse(updated)
    await db.table('tenants').put(updated)
    return updated
  }
  async removeTenant(id: string): Promise<void> {
    await this.init()
    const t = await this.getTenantById(id)
    if (t?.leaseId) throw new Error('Cannot delete tenant with active lease')
    await db.table('tenants').delete(id)
  }

  // Leases
  async listLeases(): Promise<Lease[]> {
    await this.init()
    return db.table('leases').toArray()
  }
  async getLeaseById(id: string): Promise<Lease | undefined> {
    await this.init()
    return db.table('leases').get(id)
  }
  async startLeaseForTenant(input: { tenantId: string; propertyId: string; startDate: string; endDate: string; rentAmount: number; currency: 'ILS' | 'USD' | 'EUR' }): Promise<Lease> {
    await this.init()
    const now = new Date().toISOString()
    const entity: Lease = {
      id: nanoid(),
      tenantId: input.tenantId,
      propertyId: input.propertyId,
      startDate: input.startDate,
      endDate: input.endDate,
      rentAmount: input.rentAmount,
      currency: input.currency,
      optionIds: [],
      createdAt: now,
      updatedAt: now,
    }
    leaseSchema.parse(entity)
    await db.table('leases').add(entity)
    // link tenant & property
    const t = await this.getTenantById(input.tenantId)
    if (t) await this.updateTenant(t.id, { leaseId: entity.id, propertyId: input.propertyId })
    await this.updateProperty(input.propertyId, { status: 'occupied' } as any)
    return entity
  }
  async updateLease(id: string, patch: Partial<Lease>): Promise<Lease> {
    await this.init()
    const current = await this.getLeaseById(id)
    if (!current) throw new Error('Lease not found')
    const updated = { ...current, ...patch, id, updatedAt: new Date().toISOString() } as Lease
    leaseSchema.parse(updated)
    await db.table('leases').put(updated)
    return updated
  }
  async endLease(id: string, endDateISO: string): Promise<void> {
    await this.init()
    const current = await this.getLeaseById(id)
    if (!current) return
    await this.updateLease(id, { endDate: endDateISO })
    // unlink tenant & free property
    const t = await this.getTenantById(current.tenantId)
    if (t) await this.updateTenant(t.id, { leaseId: undefined })
    await this.updateProperty(current.propertyId, { status: 'vacant' } as any)
  }

  // Options
  async addOptionToLease(leaseId: string, input: Omit<Option, 'id' | 'leaseId' | 'createdAt' | 'updatedAt'>): Promise<Option> {
    await this.init()
    const now = new Date().toISOString()
    const entity: Option = { id: nanoid(), leaseId, startDate: input.startDate, endDate: input.endDate, price: input.price, createdAt: now, updatedAt: now }
    optionSchema.parse(entity)
    await db.table('options').add(entity)
    const l = await this.getLeaseById(leaseId)
    if (l) {
      const updated = { ...l, optionIds: [...(l.optionIds || []), entity.id] }
      await db.table('leases').put(updated)
    }
    return entity
  }
}
