import Dexie from 'dexie'

export class PMDb extends Dexie {
  properties!: Dexie.Table<any, string>
  tenants!: Dexie.Table<any, string>
  leases!: Dexie.Table<any, string>
  options!: Dexie.Table<any, string>
  meta!: Dexie.Table<any, string>
  files!: Dexie.Table<any, string>

  constructor() {
    super('pm')
    this.version(2).stores({
      properties: 'id, name, type, status, updatedAt',
      tenants: 'id, fullName, status, propertyId, leaseId, updatedAt',
      leases: 'id, tenantId, propertyId, endDate, updatedAt',
      options: 'id, leaseId, endDate, updatedAt',
      meta: 'key',
      files: 'id, name, createdAt',
    })
  }
}

const db = new PMDb()
export default db
